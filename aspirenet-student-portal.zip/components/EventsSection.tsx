
import React from 'react';
import { EventItem } from '../types';
import { Calendar } from 'lucide-react';

interface EventsSectionProps {
    events: EventItem[];
}

const EventsSection: React.FC<EventsSectionProps> = ({ events }) => {
    return (
        <div className="mt-16">
            <div className="text-center mb-10">
                <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white inline-flex items-center">
                    <Calendar className="mr-3 h-8 w-8 text-indigo-500" />
                    Latest Events & Workshops
                </h2>
                <p className="mt-3 max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-300">
                    Stay updated with our latest workshops, seminars, and success stories.
                </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {events.map(event => (
                    <div key={event.id} className="group relative rounded-xl overflow-hidden shadow-lg transform hover:-translate-y-2 transition-transform duration-300">
                        <img src={event.imageUrl} alt={event.title} className="w-full h-72 object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                        <div className="absolute bottom-0 left-0 p-6">
                            <h3 className="text-white text-2xl font-bold">{event.title}</h3>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default EventsSection;
