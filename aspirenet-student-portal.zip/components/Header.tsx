
import React from 'react';
import { User } from '../types';
import { BookOpen, LogIn, LogOut } from 'lucide-react';

interface HeaderProps {
  currentUser: User | null;
  onLoginClick: () => void;
  onLogout: () => void;
  onHomeClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentUser, onLoginClick, onLogout, onHomeClick }) => {
  return (
    <header className="bg-white dark:bg-slate-800 shadow-md sticky top-0 z-40">
      <div className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
        <button onClick={onHomeClick} className="flex items-center space-x-3 cursor-pointer">
          <BookOpen className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">AspireNet Portal</h1>
        </button>
        <div className="flex items-center space-x-4">
          {currentUser ? (
            <>
              <span className="text-sm font-medium text-slate-700 dark:text-slate-300 hidden sm:block">
                Welcome, <span className="font-bold">{currentUser.name}</span> ({currentUser.role})
              </span>
              <button
                onClick={onLogout}
                className="px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-300 flex items-center space-x-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600"
              >
                <LogOut size={16} />
                <span>Logout</span>
              </button>
            </>
          ) : (
            <button
              onClick={onLoginClick}
              className="px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-300 flex items-center space-x-2 bg-indigo-600 text-white hover:bg-indigo-700"
            >
              <LogIn size={16} />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;