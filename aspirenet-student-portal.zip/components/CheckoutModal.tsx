
import React from 'react';
import { PdfMaterial } from '../types';
import { X, Trash2, CreditCard } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: PdfMaterial[];
  onRemoveFromCart: (pdfId: string) => void;
  onPurchase: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, cartItems, onRemoveFromCart, onPurchase }) => {
  if (!isOpen) return null;

  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  const handlePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    onPurchase();
    alert("Purchase successful! You can now view your new materials.");
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full max-w-2xl transform transition-all" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-6 border-b border-slate-200 dark:border-slate-700">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Your Cart</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          {cartItems.length === 0 ? (
            <p className="text-center text-slate-500 dark:text-slate-400 py-8">Your cart is empty.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Order Summary</h3>
                <ul className="space-y-3 max-h-60 overflow-y-auto pr-2">
                  {cartItems.map(item => (
                    <li key={item.id} className="flex justify-between items-center">
                      <span className="flex-1 pr-2 text-slate-700 dark:text-slate-300">{item.title}</span>
                      <span className="font-semibold text-slate-900 dark:text-white">${item.price.toFixed(2)}</span>
                      <button onClick={() => onRemoveFromCart(item.id)} className="ml-4 text-red-500 hover:text-red-700">
                        <Trash2 size={16} />
                      </button>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center"><CreditCard className="mr-2"/> Payment Details</h3>
                <form onSubmit={handlePurchase} className="space-y-4">
                   <div>
                      <label htmlFor="card-name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Name on Card</label>
                      <input type="text" id="card-name" placeholder="John Doe" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                    </div>
                     <div>
                      <label htmlFor="card-number" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Card Number (mock)</label>
                      <input type="text" id="card-number" placeholder="**** **** **** 1234" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                    </div>
                    <div className="flex space-x-4">
                         <div className="flex-1">
                          <label htmlFor="card-expiry" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Expiry</label>
                          <input type="text" id="card-expiry" placeholder="MM/YY" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div className="flex-1">
                          <label htmlFor="card-cvc" className="block text-sm font-medium text-slate-700 dark:text-slate-300">CVC</label>
                          <input type="text" id="card-cvc" placeholder="123" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                    </div>
                   <button type="submit" className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
                      Pay ${total.toFixed(2)}
                   </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;
