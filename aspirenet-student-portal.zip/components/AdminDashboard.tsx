
import React, { useState } from 'react';
import { LayoutDashboard, FileText, Bell, Calendar, Settings, LogOut } from 'lucide-react';
import ManageMaterials from './ManageMaterials';
import ManageNotifications from './ManageNotifications';
import ManageEvents from './ManageEvents';
import ContactDetailsForm from './ContactDetailsForm';

type AdminView = 'dashboard' | 'notifications' | 'events' | 'settings';

const AdminDashboard: React.FC = () => {
  const [activeView, setActiveView] = useState<AdminView>('dashboard');

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'settings', label: 'Site Settings', icon: Settings },
  ];

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <ManageMaterials />;
      case 'notifications':
        return <ManageNotifications />;
      case 'events':
        return <ManageEvents />;
      case 'settings':
        return (
          <div>
            <h2 className="text-3xl font-bold mb-6 text-slate-800 dark:text-slate-100">Site Settings</h2>
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md max-w-2xl">
              <ContactDetailsForm />
            </div>
          </div>
        );
      default:
        return <ManageMaterials />;
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-150px)]">
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-slate-800 p-4 flex flex-col shadow-lg rounded-lg mr-8">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 px-2">Admin Panel</h2>
        <nav className="flex-grow">
          <ul>
            {navItems.map(item => (
              <li key={item.id}>
                <button
                  onClick={() => setActiveView(item.id as AdminView)}
                  className={`w-full flex items-center space-x-3 px-3 py-3 my-1 rounded-md text-sm font-medium transition-colors ${
                    activeView === item.id
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  <item.icon size={20} />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1">
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminDashboard;
