
import React, { useState } from 'react';
import { Category } from '../types';

interface AddVideoFormProps {
  onAdd: (title: string, description: string, youtubeId: string, category: Category) => void;
}

const AddVideoForm: React.FC<AddVideoFormProps> = ({ onAdd }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [category, setCategory] = useState<Category>(Category.HS);
  const [error, setError] = useState('');

  const extractVideoId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const videoId = extractVideoId(youtubeUrl);
    if (!title || !description || !videoId || !category) {
      setError('Please fill all fields and provide a valid YouTube URL.');
      return;
    }
    setError('');
    onAdd(title, description, videoId, category);
    setTitle('');
    setDescription('');
    setYoutubeUrl('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="video-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Title</label>
        <input type="text" id="video-title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
      <div>
        <label htmlFor="video-description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
        <textarea id="video-description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"></textarea>
      </div>
      <div>
        <label htmlFor="video-url" className="block text-sm font-medium text-slate-700 dark:text-slate-300">YouTube URL</label>
        <input type="text" id="video-url" value={youtubeUrl} onChange={e => setYoutubeUrl(e.target.value)} placeholder="e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
       <div>
            <label htmlFor="video-category" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Category</label>
            <select id="video-category" value={category} onChange={e => setCategory(e.target.value as Category)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                {Object.values(Category).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                ))}
            </select>
        </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
        Add Video Material
      </button>
    </form>
  );
};

export default AddVideoForm;