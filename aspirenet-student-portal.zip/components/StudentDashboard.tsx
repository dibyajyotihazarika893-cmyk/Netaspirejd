
import React, { useState } from 'react';
import { StudyMaterial, PdfMaterial, MaterialType, User, Category } from '../types';
import MaterialCard from './MaterialCard';
import PdfViewerModal from './PdfViewerModal';
import VideoPlayerModal from './VideoPlayerModal';
import { ArrowLeft } from 'lucide-react';

interface StudentDashboardProps {
  materials: StudyMaterial[];
  purchasedPdfIds: Set<string>;
  onAddToCart: (pdf: PdfMaterial) => void;
  currentUser: User | null;
  onLoginRequired: (pdfToAdd?: PdfMaterial) => void;
  category: Category;
  onBack: () => void;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ materials, purchasedPdfIds, onAddToCart, currentUser, onLoginRequired, category, onBack }) => {
  const [selectedPdfUrl, setSelectedPdfUrl] = useState<string | null>(null);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);

  const handleViewPdf = (pdf: PdfMaterial) => {
    if (!currentUser) {
      onLoginRequired();
      return;
    }
    // In a real app with proper URLs, we would just use pdf.fileUrl
    // For this mock, we use a placeholder for free PDFs that haven't been "uploaded"
    if (pdf.fileUrl) {
      setSelectedPdfUrl(pdf.fileUrl);
    } else {
       // Placeholder for initial mock data that doesn't have a file
       alert("This PDF is not available for viewing yet.");
    }
  };
  
  const handleViewVideo = (youtubeId: string) => {
    if (!currentUser) {
      onLoginRequired();
      return;
    }
    setSelectedVideoId(youtubeId);
  };
  
  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="mr-4 p-2 rounded-full bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">
          <ArrowLeft className="h-6 w-6 text-slate-700 dark:text-slate-200" />
        </button>
        <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">{category} Learning Materials</h2>
      </div>

      {materials.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {materials.map(material => (
            <MaterialCard
              key={material.id}
              material={material}
              isPurchased={material.type === MaterialType.PDF && purchasedPdfIds.has(material.id)}
              onViewPdf={handleViewPdf}
              onViewVideo={handleViewVideo}
              onAddToCart={onAddToCart}
              currentUser={currentUser}
              onLoginRequired={onLoginRequired}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200">No Materials Yet</h3>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Check back soon! We're always adding new content for the {category} category.</p>
        </div>
      )}
      
      {selectedPdfUrl && <PdfViewerModal fileUrl={selectedPdfUrl} onClose={() => setSelectedPdfUrl(null)} />}
      {selectedVideoId && <VideoPlayerModal youtubeId={selectedVideoId} onClose={() => setSelectedVideoId(null)} />}
    </div>
  );
};

export default StudentDashboard;