
import React from 'react';
import { X } from 'lucide-react';

interface PdfViewerModalProps {
  fileUrl: string;
  onClose: () => void;
}

const PdfViewerModal: React.FC<PdfViewerModalProps> = ({ fileUrl, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full h-full max-w-4xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">PDF Viewer</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white">
            <X size={24} />
          </button>
        </div>
        <div className="flex-grow p-2">
          <iframe
            src={fileUrl}
            className="w-full h-full border-none"
            title="PDF Viewer"
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default PdfViewerModal;
