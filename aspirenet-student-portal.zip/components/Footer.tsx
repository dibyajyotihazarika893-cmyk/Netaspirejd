
import React from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { Mail, Phone, MapPin, BookOpen } from 'lucide-react';

const Footer: React.FC = () => {
    const { contactDetails } = useDatabase();

    return (
        <footer className="bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 mt-12 shadow-inner">
            <div className="container mx-auto px-4 md:px-8 py-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
                    <div className="flex flex-col items-center md:items-start">
                        <div className="flex items-center space-x-3 mb-4">
                            <BookOpen className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                            <h2 className="text-xl font-bold text-slate-900 dark:text-white">AspireNet Portal</h2>
                        </div>
                        <p className="text-sm">Your partner in competitive exam preparation. Access high-quality notes and video lectures anytime, anywhere.</p>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Contact Us</h3>
                        <ul className="space-y-2 text-sm">
                            <li className="flex items-center justify-center md:justify-start space-x-2">
                                <Mail size={16} />
                                <a href={`mailto:${contactDetails.email}`} className="hover:text-indigo-600 dark:hover:text-indigo-400">{contactDetails.email}</a>
                            </li>
                             <li className="flex items-center justify-center md:justify-start space-x-2">
                                <Phone size={16} />
                                <span>{contactDetails.phone}</span>
                            </li>
                             <li className="flex items-center justify-center md:justify-start space-x-2">
                                <MapPin size={16} />
                                <span>{contactDetails.address}</span>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Quick Links</h3>
                         <ul className="space-y-2 text-sm">
                           <li><a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400">Home</a></li>
                           <li><a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400">About Us</a></li>
                           <li><a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400">Terms of Service</a></li>
                        </ul>
                    </div>
                </div>
                <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-700 text-center text-sm">
                    <p>&copy; {new Date().getFullYear()} AspireNet Portal. All Rights Reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
