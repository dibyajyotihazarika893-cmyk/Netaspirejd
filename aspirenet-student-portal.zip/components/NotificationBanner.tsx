
import React, { useState, useEffect } from 'react';
import { Notification } from '../types';
import { Megaphone, X } from 'lucide-react';

interface NotificationBannerProps {
  notification: Notification;
}

const NotificationBanner: React.FC<NotificationBannerProps> = ({ notification }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // This effect ensures the banner is visible when the notification changes
    // and triggers the animation.
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, [notification.id]);


  if (!isVisible) {
    return null;
  }

  return (
    <div 
        className={`relative bg-indigo-600 text-white rounded-lg shadow-lg mb-8 overflow-hidden transition-all duration-500 ease-out ${
            isVisible ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'
        }`}
    >
        <div className="container mx-auto py-3 px-4 flex items-center justify-center text-center">
            <Megaphone className="h-5 w-5 mr-3 flex-shrink-0" />
            <p className="text-sm font-medium">
                <strong>Announcement:</strong> {notification.message}
            </p>
            <button 
                onClick={() => setIsVisible(false)} 
                className="absolute top-1/2 right-4 transform -translate-y-1/2 p-1 rounded-full hover:bg-indigo-500 transition-colors"
                aria-label="Dismiss notification"
            >
                <X size={18} />
            </button>
        </div>
    </div>
  );
};

export default NotificationBanner;
