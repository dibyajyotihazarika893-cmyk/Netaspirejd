
import React from 'react';
import { X } from 'lucide-react';

interface VideoPlayerModalProps {
  youtubeId: string;
  onClose: () => void;
}

const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({ youtubeId, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-black rounded-lg shadow-2xl w-full max-w-4xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-end p-2">
            <button onClick={onClose} className="text-white hover:text-slate-300">
                <X size={24} />
            </button>
        </div>
        <div className="aspect-w-16 aspect-h-9">
          <iframe
            className="w-full h-full"
            src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1`}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayerModal;
