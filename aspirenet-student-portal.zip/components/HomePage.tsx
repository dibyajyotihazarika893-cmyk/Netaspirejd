
import React from 'react';
import { Category, Notification, EventItem } from '../types';
import { BookCopy, Landmark, Layers, Award } from 'lucide-react';
import NotificationBanner from './NotificationBanner';
import EventsSection from './EventsSection';

interface HomePageProps {
  onSelectCategory: (category: Category) => void;
  notifications: Notification[];
  events: EventItem[];
}

const categoryDetails = {
  [Category.UPSC]: { icon: Landmark, description: "Union Public Service Commission materials for aspiring civil servants." },
  [Category.SSC]: { icon: Layers, description: "Staff Selection Commission resources for various government jobs." },
  [Category.APSC]: { icon: BookCopy, description: "Assam Public Service Commission exam preparation guides." },
  [Category.HS]: { icon: Award, description: "Higher Secondary level notes and guides for board exam excellence." },
};

const HomePage: React.FC<HomePageProps> = ({ onSelectCategory, notifications, events }) => {
  const latestNotification = notifications.length > 0 ? notifications[0] : null;

  return (
    <div>
      {latestNotification && <NotificationBanner notification={latestNotification} />}

      <div className="text-center py-10 px-4">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white">
          Welcome to Your Learning Hub
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-300">
          Select a category to begin your preparation journey. We have curated notes and videos for every goal.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mt-8">
        {Object.values(Category).map(category => {
          const details = categoryDetails[category];
          const Icon = details.icon;
          return (
            <button
              key={category}
              onClick={() => onSelectCategory(category)}
              className="group bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl text-center flex flex-col items-center transform hover:-translate-y-2 transition-all duration-300"
            >
              <div className="bg-indigo-100 dark:bg-indigo-900 p-5 rounded-full mb-5 group-hover:bg-indigo-500 transition-colors duration-300">
                <Icon className="h-10 w-10 text-indigo-600 dark:text-indigo-300 group-hover:text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-2">{category}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                {details.description}
              </p>
            </button>
          );
        })}
      </div>
      
      {events.length > 0 && <EventsSection events={events} />}

    </div>
  );
};

export default HomePage;
