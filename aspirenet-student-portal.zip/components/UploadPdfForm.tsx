
import React, { useState } from 'react';
import { UploadCloud } from 'lucide-react';
import { Category } from '../types';

interface UploadPdfFormProps {
  onUpload: (title: string, description: string, price: number, file: File, category: Category) => void;
}

const UploadPdfForm: React.FC<UploadPdfFormProps> = ({ onUpload }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('0');
  const [file, setFile] = useState<File | null>(null);
  const [category, setCategory] = useState<Category>(Category.HS);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !file || !category) {
      setError('All fields are required.');
      return;
    }
    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file.');
      return;
    }
    setError('');
    onUpload(title, description, parseFloat(price), file, category);
    setTitle('');
    setDescription('');
    setPrice('0');
    setFile(null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="pdf-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Title</label>
        <input type="text" id="pdf-title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
      <div>
        <label htmlFor="pdf-description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
        <textarea id="pdf-description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"></textarea>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="pdf-price" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Price (0 for free)</label>
          <input type="number" id="pdf-price" value={price} onChange={e => setPrice(e.target.value)} min="0" step="0.01" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
        </div>
        <div>
            <label htmlFor="pdf-category" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Category</label>
            <select id="pdf-category" value={category} onChange={e => setCategory(e.target.value as Category)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                {Object.values(Category).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                ))}
            </select>
        </div>
      </div>
      <div>
        <label htmlFor="pdf-file" className="block text-sm font-medium text-slate-700 dark:text-slate-300">PDF File</label>
        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md">
            <div className="space-y-1 text-center">
                <UploadCloud className="mx-auto h-12 w-12 text-slate-400" />
                <div className="flex text-sm text-slate-600 dark:text-slate-400">
                    <label htmlFor="pdf-file" className="relative cursor-pointer bg-white dark:bg-slate-800 rounded-md font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                        <span>Upload a file</span>
                        <input id="pdf-file" name="pdf-file" type="file" className="sr-only" accept="application/pdf" onChange={e => setFile(e.target.files ? e.target.files[0] : null)} />
                    </label>
                </div>
                 {file ? <p className="text-sm text-slate-500">{file.name}</p> : <p className="text-xs text-slate-500">PDF up to 10MB</p>}
            </div>
        </div>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
        Add PDF Material
      </button>
    </form>
  );
};

export default UploadPdfForm;