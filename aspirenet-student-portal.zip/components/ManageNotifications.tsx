
import React, { useState } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { Bell, Trash2, Send } from 'lucide-react';

const ManageNotifications: React.FC = () => {
    const { notifications, addNotification, deleteNotification } = useDatabase();
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!message.trim()) {
            setError('Notification message cannot be empty.');
            return;
        }
        setError('');
        addNotification(message);
        setMessage('');
    }

    return (
        <div>
            <h2 className="text-3xl font-bold mb-6 text-slate-800 dark:text-slate-100">Manage Notifications</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                     <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Post a New Notification</h3>
                    <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="notification-message" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
                                <textarea 
                                    id="notification-message" 
                                    value={message} 
                                    onChange={e => setMessage(e.target.value)} 
                                    rows={4} 
                                    className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                    placeholder="e.g., New UPSC batch starts next Monday!"
                                ></textarea>
                            </div>
                            {error && <p className="text-sm text-red-600">{error}</p>}
                            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
                                <Send size={16}/>
                                <span>Post Notification</span>
                            </button>
                        </form>
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Active Notifications ({notifications.length})</h3>
                     <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md max-h-[600px] overflow-y-auto">
                        {notifications.length > 0 ? (
                            <ul className="divide-y divide-slate-200 dark:divide-slate-700">
                                {notifications.map(n => (
                                <li key={n.id} className="py-3 flex items-center justify-between space-x-4">
                                    <div className="flex items-start space-x-3">
                                        <Bell className="text-amber-500 mt-1 flex-shrink-0" />
                                        <div>
                                            <p className="text-slate-800 dark:text-slate-100">{n.message}</p>
                                            <p className="text-xs text-slate-400 dark:text-slate-500">
                                                Posted on: {new Date(n.date).toLocaleDateString()}
                                            </p>
                                        </div>
                                    </div>
                                    <button onClick={() => deleteNotification(n.id)} className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50">
                                        <Trash2 size={18} />
                                    </button>
                                </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center py-8 text-slate-500 dark:text-slate-400">No active notifications.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ManageNotifications;
