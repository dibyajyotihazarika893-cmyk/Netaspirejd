
import React from 'react';
import { StudyMaterial, MaterialType, PdfMaterial, User } from '../types';
import { FileText, Video, Eye, ShoppingCart, CheckCircle, LogIn } from 'lucide-react';

interface MaterialCardProps {
  material: StudyMaterial;
  isPurchased: boolean;
  onViewPdf: (pdf: PdfMaterial) => void;
  onViewVideo: (youtubeId: string) => void;
  onAddToCart: (pdf: PdfMaterial) => void;
  currentUser: User | null;
  onLoginRequired: (pdfToAdd?: PdfMaterial) => void;
}

const MaterialCard: React.FC<MaterialCardProps> = ({ material, isPurchased, onViewPdf, onViewVideo, onAddToCart, currentUser, onLoginRequired }) => {
  const isPdf = material.type === MaterialType.PDF;

  const renderAction = () => {
    // User is not logged in
    if (!currentUser) {
      const isPayable = isPdf && material.price > 0;
      return (
        <button
          onClick={() => onLoginRequired(isPayable ? material : undefined)}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors"
        >
          <LogIn size={18} />
          <span>
            {isPdf ? (material.price > 0 ? `Login to Buy for $${material.price.toFixed(2)}` : 'Login to View') : 'Login to Watch'}
          </span>
        </button>
      );
    }
    
    // User is logged in
    if (!isPdf) {
      return (
        <button
          onClick={() => onViewVideo(material.youtubeId)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors"
        >
          <Eye size={18} />
          <span>Watch Video</span>
        </button>
      );
    }

    if (material.price === 0 || isPurchased) {
      return (
        <button
          onClick={() => onViewPdf(material)}
          disabled={material.price > 0 && !isPurchased && !material.fileUrl}
          className="w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors disabled:bg-slate-400 disabled:cursor-not-allowed"
        >
          {isPurchased ? <CheckCircle size={18} /> : <Eye size={18} />}
          <span>{isPurchased ? 'View Purchased' : 'View Free PDF'}</span>
        </button>
      );
    }

    return (
      <button
        onClick={() => onAddToCart(material)}
        className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors"
      >
        <ShoppingCart size={18} />
        <span>Buy for ${material.price.toFixed(2)}</span>
      </button>
    );
  };
  
  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden flex flex-col transition-transform transform hover:-translate-y-1">
      <div className="p-6 flex-grow">
        <div className="flex items-center mb-4">
          {isPdf ? <FileText className="h-8 w-8 text-red-500 mr-3" /> : <Video className="h-8 w-8 text-blue-500 mr-3" />}
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">{material.title}</h3>
        </div>
        <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 h-20">{material.description}</p>
      </div>
      <div className="p-6 bg-slate-50 dark:bg-slate-800/50">
        {renderAction()}
      </div>
    </div>
  );
};

export default MaterialCard;