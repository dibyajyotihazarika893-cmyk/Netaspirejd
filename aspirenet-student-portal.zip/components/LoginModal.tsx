
import React, { useState, useEffect } from 'react';
import { X, User as UserIcon, UserCog, Smartphone, KeyRound, ArrowLeft } from 'lucide-react';
import { User, UserRole } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
}

// A simple SVG for Google icon as lucide-react doesn't have it.
const GoogleIcon = () => (
    <svg className="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
        <path fill="currentColor" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 126 23.4 172.9 61.9l-69.2 69.2c-20.9-19.8-49.8-32.3-82.7-32.3-64.3 0-116.8 52.5-116.8 116.8s52.5 116.8 116.8 116.8c70.3 0 98.7-52.9 103.5-77.9H248v-96.5h239.1c1.3 12.8 2.9 25.8 2.9 39.5z"></path>
    </svg>
);


const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [view, setView] = useState<'main' | 'admin' | 'google' | 'phone'>('main');
  const [error, setError] = useState('');

  // Common fields
  const [name, setName] = useState('');

  // Admin fields
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Phone fields
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);

  const resetForms = () => {
    setError('');
    setName('');
    setUsername('');
    setPassword('');
    setPhoneNumber('');
    setOtp('');
    setIsOtpSent(false);
  };

  useEffect(() => {
    if (!isOpen) {
      // Give a little time for closing animation before resetting state
      setTimeout(() => {
        setView('main');
        resetForms();
      }, 300);
    }
  }, [isOpen]);

  const handleBack = () => {
    setView('main');
    resetForms();
  };
  
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'password') {
      onLogin({ id: 'admin-user', name: 'Admin', role: UserRole.Admin });
      onClose();
    } else {
      setError('Invalid username or password.');
    }
  };

  const handleGoogleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }
    onLogin({ id: `user-${Date.now()}`, name: name.trim(), role: UserRole.Student });
    onClose();
  };
  
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) { // Simple validation
        setError('Please enter a valid phone number.');
        return;
    }
     if (!name.trim()) {
      setError('Please enter your name to associate with this number.');
      return;
    }
    setError('');
    setIsOtpSent(true);
    // In a real app, an API call to send OTP would be made here.
    // We can show a temporary success message.
    setTimeout(() => alert(`An OTP has been sent to ${phoneNumber}. (Hint: it's 123456)`), 500);
  };

  const handlePhoneLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp === '123456') {
      onLogin({ id: `user-${Date.now()}`, name: name.trim(), role: UserRole.Student });
      onClose();
    } else {
      setError('Invalid OTP. Please try again.');
    }
  };


  if (!isOpen) return null;

  const renderMainView = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Welcome to AspireNet</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">Choose your login method</p>
      </div>
      <div className="space-y-3">
        <button onClick={() => setView('admin')} className="w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
          <UserCog size={20} />
          <span>Login as Admin</span>
        </button>
        <button onClick={() => setView('google')} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
          <GoogleIcon />
          <span>Sign in with Google</span>
        </button>
        <button onClick={() => setView('phone')} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
          <Smartphone size={20} />
          <span>Sign in with Phone Number</span>
        </button>
      </div>
    </>
  );

  const renderAdminView = () => (
    <form onSubmit={handleAdminLogin} className="space-y-4">
      <h3 className="font-bold text-lg text-center">Admin Login</h3>
      <div>
        <label htmlFor="username" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Username</label>
        <input type="text" id="username" value={username} onChange={e => setUsername(e.target.value)} placeholder="admin" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
       <div>
        <label htmlFor="password"className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
        <input type="password" id="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="password" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
      <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
        <KeyRound size={18} />
        <span>Login</span>
      </button>
    </form>
  );
  
  const renderGoogleView = () => (
     <form onSubmit={handleGoogleLogin} className="space-y-4">
      <h3 className="font-bold text-lg text-center flex items-center justify-center space-x-2"><GoogleIcon /> <span>Sign in as Student</span></h3>
      <p className="text-xs text-center text-slate-500">Simulating Google Sign-in. Please provide your name to create an account.</p>
       <div>
        <label htmlFor="g-name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Your Name</label>
        <input type="text" id="g-name" value={name} onChange={e => setName(e.target.value)} placeholder="Alex Doe" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
      </div>
       <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
        <UserIcon size={18} />
        <span>Complete Sign-in</span>
      </button>
    </form>
  );

  const renderPhoneView = () => (
     <form onSubmit={isOtpSent ? handlePhoneLogin : handleSendOtp} className="space-y-4">
       <h3 className="font-bold text-lg text-center flex items-center justify-center space-x-2"><Smartphone /> <span>Sign in with Phone</span></h3>
       {!isOtpSent ? (
        <>
            <div>
              <label htmlFor="p-name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Your Name</label>
              <input type="text" id="p-name" value={name} onChange={e => setName(e.target.value)} placeholder="Alex Doe" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Phone Number</label>
              <input type="tel" id="phone" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} placeholder="e.g., 123-456-7890" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
            <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg">Send Verification Code</button>
        </>
       ) : (
         <>
            <p className="text-sm text-center text-slate-500 dark:text-slate-400">Enter the 6-digit code sent to your device.</p>
            <div>
              <label htmlFor="otp" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Verification Code</label>
              <input type="text" id="otp" value={otp} onChange={e => setOtp(e.target.value)} placeholder="123456" maxLength={6} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg">Verify & Login</button>
         </>
       )}
     </form>
  );

  const renderContent = () => {
    switch (view) {
      case 'admin': return renderAdminView();
      case 'google': return renderGoogleView();
      case 'phone': return renderPhoneView();
      case 'main':
      default:
        return renderMainView();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 transition-opacity" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full max-w-sm transform transition-all" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-5 border-b border-slate-200 dark:border-slate-700">
           {view !== 'main' ? (
             <button onClick={handleBack} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white flex items-center space-x-2 text-sm">
                <ArrowLeft size={18} />
                <span>Back</span>
            </button>
           ) : <div className="w-16"></div>}
          <h2 className="text-lg font-semibold text-slate-700 dark:text-white">AspireNet</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
            {renderContent()}
            {error && <p className="text-sm text-red-500 mt-4 text-center">{error}</p>}
        </div>
      </div>
    </div>
  );
};

export default LoginModal;
