
import React, { useState } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { UploadCloud, Trash2, ImagePlus } from 'lucide-react';

const ManageEvents: React.FC = () => {
    const { events, addEvent, deleteEvent } = useDatabase();
    const [title, setTitle] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [preview, setPreview] = useState<string | null>(null);
    const [error, setError] = useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files ? e.target.files[0] : null;
        if (selectedFile) {
            if (!selectedFile.type.startsWith('image/')) {
                setError('Please upload a valid image file (JPEG, PNG, GIF).');
                return;
            }
            setError('');
            setFile(selectedFile);
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result as string);
            };
            reader.readAsDataURL(selectedFile);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !file || !preview) {
            setError('Event title and image are required.');
            return;
        }
        setError('');
        addEvent(title, preview);
        setTitle('');
        setFile(null);
        setPreview(null);
    };

    return (
        <div>
            <h2 className="text-3xl font-bold mb-6 text-slate-800 dark:text-slate-100">Manage Events</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Add New Event</h3>
                    <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="event-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Event Title</label>
                                <input type="text" id="event-title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Event Image</label>
                                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md">
                                    <div className="space-y-1 text-center">
                                        {preview ? (
                                            <img src={preview} alt="Event preview" className="mx-auto h-24 w-auto rounded-md" />
                                        ) : (
                                            <UploadCloud className="mx-auto h-12 w-12 text-slate-400" />
                                        )}
                                        <div className="flex text-sm text-slate-600 dark:text-slate-400">
                                            <label htmlFor="event-file" className="relative cursor-pointer bg-white dark:bg-slate-800 rounded-md font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                                <span>{file ? 'Change image' : 'Upload an image'}</span>
                                                <input id="event-file" name="event-file" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                                            </label>
                                        </div>
                                        {file ? <p className="text-sm text-slate-500 truncate">{file.name}</p> : <p className="text-xs text-slate-500">PNG, JPG, GIF up to 5MB</p>}
                                    </div>
                                </div>
                            </div>
                            {error && <p className="text-sm text-red-600">{error}</p>}
                            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
                                <ImagePlus size={18}/>
                                <span>Add Event</span>
                            </button>
                        </form>
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Current Events ({events.length})</h3>
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md max-h-[600px] overflow-y-auto">
                        {events.length > 0 ? (
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {events.map(event => (
                                    <div key={event.id} className="relative group bg-slate-100 dark:bg-slate-700 rounded-lg overflow-hidden">
                                        <img src={event.imageUrl} alt={event.title} className="h-48 w-full object-cover" />
                                        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end p-4">
                                            <h4 className="text-white font-bold text-lg">{event.title}</h4>
                                        </div>
                                        <button 
                                            onClick={() => deleteEvent(event.id)}
                                            className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                            aria-label="Delete event"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                ))}
                           </div>
                        ) : (
                             <p className="text-center py-8 text-slate-500 dark:text-slate-400">No events have been added yet.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ManageEvents;
