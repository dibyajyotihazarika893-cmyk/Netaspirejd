
import React, { useState } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { StudyMaterial, MaterialType, PdfMaterial, VideoMaterial, Category } from '../types';
import UploadPdfForm from './UploadPdfForm';
import AddVideoForm from './AddVideoForm';
import { FileText, Video, Tag } from 'lucide-react';

const ManageMaterials: React.FC = () => {
  const { materials, addMaterial } = useDatabase();
  const [activeTab, setActiveTab] = useState<'pdf' | 'video'>('pdf');

  const handlePdfUpload = (title: string, description: string, price: number, file: File, category: Category) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const newPdf: PdfMaterial = {
        id: `pdf-${Date.now()}`,
        type: MaterialType.PDF,
        title,
        description,
        price,
        fileUrl: e.target?.result as string,
        category,
      };
      addMaterial(newPdf);
    };
    reader.readAsDataURL(file);
  };

  const handleVideoAdd = (title: string, description: string, youtubeId: string, category: Category) => {
    const newVideo: VideoMaterial = {
      id: `video-${Date.now()}`,
      type: MaterialType.Video,
      title,
      description,
      youtubeId,
      category,
    };
    addMaterial(newVideo);
  };

  return (
    <div>
        <h2 className="text-3xl font-bold mb-6 text-slate-800 dark:text-slate-100">Content Dashboard</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
                <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Add New Content</h3>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md">
                <div className="flex border-b border-slate-200 dark:border-slate-700">
                    <button
                    onClick={() => setActiveTab('pdf')}
                    className={`flex-1 py-3 px-4 text-center font-semibold flex items-center justify-center space-x-2 ${activeTab === 'pdf' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 dark:text-slate-400'}`}
                    >
                    <FileText size={18} />
                    <span>Add PDF</span>
                    </button>
                    <button
                    onClick={() => setActiveTab('video')}
                    className={`flex-1 py-3 px-4 text-center font-semibold flex items-center justify-center space-x-2 ${activeTab === 'video' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 dark:text-slate-400'}`}
                    >
                    <Video size={18} />
                    <span>Add Video</span>
                    </button>
                </div>
                <div className="p-2 pt-6">
                    {activeTab === 'pdf' ? (
                    <UploadPdfForm onUpload={handlePdfUpload} />
                    ) : (
                    <AddVideoForm onAdd={handleVideoAdd} />
                    )}
                </div>
                </div>
            </div>
            <div className="lg:col-span-2">
                <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Current Materials ({materials.length})</h3>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md max-h-[600px] overflow-y-auto">
                <ul className="divide-y divide-slate-200 dark:divide-slate-700">
                    {materials.map(m => (
                    <li key={m.id} className="py-3 flex items-start space-x-4">
                        {m.type === 'pdf' ? <FileText className="text-red-500 mt-1"/> : <Video className="text-blue-500 mt-1"/>}
                        <div className="flex-1">
                            <p className="font-semibold text-slate-800 dark:text-slate-100">{m.title}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">{m.description.substring(0, 70)}...</p>
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                                <Tag size={12} className="mr-1"/>
                                {m.category}
                            </span>
                        </div>
                        {m.type === 'pdf' && m.price > 0 && (
                            <span className="text-sm font-bold text-green-600 dark:text-green-400">${m.price.toFixed(2)}</span>
                        )}
                        {m.type === 'pdf' && m.price === 0 && (
                            <span className="text-sm font-bold text-gray-500 dark:text-gray-400">Free</span>
                        )}
                    </li>
                    ))}
                </ul>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ManageMaterials;
