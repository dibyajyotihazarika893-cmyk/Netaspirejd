
import { StudyMaterial, MaterialType, Category } from '../types';

export const INITIAL_MATERIALS: StudyMaterial[] = [
  {
    id: 'pdf-1',
    type: MaterialType.PDF,
    title: 'Introduction to Quantum Physics',
    description: 'A comprehensive starter guide to the world of quantum mechanics. Covers core principles.',
    price: 0,
    fileUrl: '', // In a real app this would be a URL to a stored PDF
    category: Category.HS,
  },
  {
    id: 'pdf-2',
    type: MaterialType.PDF,
    title: 'Indian Polity & Governance',
    description: 'All the constitutional articles and amendments you need for your civil services exams.',
    price: 9.99,
    fileUrl: '',
    category: Category.UPSC,
  },
  {
    id: 'video-1',
    type: MaterialType.Video,
    title: 'Assam History: Ahom Dynasty',
    description: 'A 45-minute video lecture breaking down the history of the Ahom Kingdom for APSC.',
    youtubeId: 'OYQ0_v94Jt4', // Example video ID
    category: Category.APSC,
  },
  {
    id: 'pdf-3',
    type: MaterialType.PDF,
    title: 'Quantitative Aptitude for SSC',
    description: 'In-depth notes and practice questions for the SSC CGL mathematics section.',
    price: 5.49,
    fileUrl: '',
    category: Category.SSC,
  },
    {
    id: 'video-2',
    type: MaterialType.Video,
    title: 'Modern Indian History',
    description: 'Learn about the Indian independence struggle, a key topic for the UPSC mains exam.',
    youtubeId: 'TNhaISOUy6Q', // Example video ID
    category: Category.UPSC,
  },
];