
import React, { useState, useCallback } from 'react';
import { UserRole, StudyMaterial, PdfMaterial, MaterialType, User, Category } from './types';
import Header from './components/Header';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';
import CheckoutModal from './components/CheckoutModal';
import LoginModal from './components/LoginModal';
import HomePage from './components/HomePage';
import Footer from './components/Footer';
import { ShoppingCart } from 'lucide-react';
import { useDatabase } from './context/DatabaseContext';

const App: React.FC = () => {
  const { materials, notifications, events } = useDatabase();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [cart, setCart] = useState<PdfMaterial[]>([]);
  const [purchasedPdfIds, setPurchasedPdfIds] = useState<Set<string>>(new Set());
  const [isCheckoutOpen, setCheckoutOpen] = useState(false);
  const [isLoginOpen, setLoginOpen] = useState(false);
  const [pendingCartItem, setPendingCartItem] = useState<PdfMaterial | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);

  const handleLoginRequired = useCallback((pdfToAdd?: PdfMaterial) => {
    if (pdfToAdd) {
      setPendingCartItem(pdfToAdd);
    }
    setLoginOpen(true);
  }, []);

  const addToCart = useCallback((pdf: PdfMaterial) => {
    if (!currentUser) {
      handleLoginRequired(pdf);
      return;
    }
    if (currentUser.role !== UserRole.Student) return;

    if (!cart.some(item => item.id === pdf.id) && !purchasedPdfIds.has(pdf.id)) {
      setCart(prev => [...prev, pdf]);
      setCheckoutOpen(true);
    }
  }, [currentUser, cart, purchasedPdfIds, handleLoginRequired]);

  const removeFromCart = (pdfId: string) => {
    setCart(prev => prev.filter(item => item.id !== pdfId));
  };
  
  const handlePurchase = () => {
    const newPurchasedIds = new Set(purchasedPdfIds);
    cart.forEach(item => newPurchasedIds.add(item.id));
    setPurchasedPdfIds(newPurchasedIds);
    setCart([]);
    setCheckoutOpen(false);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setLoginOpen(false);
    if (pendingCartItem && user.role === UserRole.Student) {
      addToCart(pendingCartItem);
    }
    setPendingCartItem(null);
  };
  
  const handleLogout = () => {
    setCurrentUser(null);
    setCart([]);
    setPurchasedPdfIds(new Set());
    setCheckoutOpen(false);
    setSelectedCategory(null);
  };

  const handleGoHome = () => {
    setSelectedCategory(null);
  }

  const renderContent = () => {
    if (currentUser?.role === UserRole.Admin) {
      return <AdminDashboard />;
    }
    if (selectedCategory) {
      return (
        <StudentDashboard 
          materials={materials.filter(m => m.category === selectedCategory)} 
          purchasedPdfIds={purchasedPdfIds}
          onAddToCart={addToCart}
          currentUser={currentUser}
          onLoginRequired={handleLoginRequired}
          category={selectedCategory}
          onBack={() => setSelectedCategory(null)}
        />
      );
    }
    return <HomePage 
      onSelectCategory={setSelectedCategory} 
      notifications={notifications}
      events={events}
    />;
  }

  const cartItemCount = cart.length;
  const isStudent = currentUser?.role === UserRole.Student;

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans flex flex-col">
      <Header 
        currentUser={currentUser} 
        onLoginClick={() => setLoginOpen(true)}
        onLogout={handleLogout}
        onHomeClick={handleGoHome}
      />
      
      <main className="container mx-auto p-4 md:p-8 flex-grow">
        {renderContent()}
      </main>

      {isStudent && cartItemCount > 0 && (
         <button
          onClick={() => setCheckoutOpen(true)}
          className="fixed bottom-24 right-8 bg-indigo-600 hover:bg-indigo-700 text-white font-bold p-4 rounded-full shadow-lg flex items-center justify-center transition-transform transform hover:scale-110"
          aria-label="Open shopping cart"
        >
          <ShoppingCart size={24} />
           <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center">
            {cartItemCount}
          </span>
        </button>
      )}

      {isStudent && <CheckoutModal 
        isOpen={isCheckoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cartItems={cart}
        onRemoveFromCart={removeFromCart}
        onPurchase={handlePurchase}
      />}

      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => {
          setLoginOpen(false);
          setPendingCartItem(null);
        }}
        onLogin={handleLogin}
      />
      <Footer />
    </div>
  );
};

export default App;
