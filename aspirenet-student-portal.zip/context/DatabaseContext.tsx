
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { StudyMaterial, ContactDetails, Notification, EventItem } from '../types';
import { INITIAL_MATERIALS } from '../services/mockData';

interface DatabaseContextType {
  materials: StudyMaterial[];
  addMaterial: (material: StudyMaterial) => void;
  contactDetails: ContactDetails;
  updateContactDetails: (details: ContactDetails) => void;
  notifications: Notification[];
  addNotification: (message: string) => void;
  deleteNotification: (id: string) => void;
  events: EventItem[];
  addEvent: (title: string, imageUrl: string) => void;
  deleteEvent: (id: string) => void;
}

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined);

const initialContactDetails: ContactDetails = {
    email: 'contact@aspire.net',
    phone: '+1 (234) 567-890',
    address: '123 Learning St, Knowledge City, ED 45678',
};

export const DatabaseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [materials, setMaterials] = useState<StudyMaterial[]>(INITIAL_MATERIALS);
  const [contactDetails, setContactDetails] = useState<ContactDetails>(initialContactDetails);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);

  const addMaterial = (material: StudyMaterial) => {
    setMaterials(prev => [material, ...prev]);
  };

  const updateContactDetails = (details: ContactDetails) => {
    setContactDetails(details);
  };
  
  const addNotification = (message: string) => {
    const newNotification: Notification = {
      id: `notif-${Date.now()}`,
      message,
      date: new Date().toISOString(),
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }

  const addEvent = (title: string, imageUrl: string) => {
    const newEvent: EventItem = {
      id: `event-${Date.now()}`,
      title,
      imageUrl,
    };
    setEvents(prev => [newEvent, ...prev]);
  }

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  }


  const value = { 
    materials, 
    addMaterial,
    contactDetails,
    updateContactDetails,
    notifications,
    addNotification,
    deleteNotification,
    events,
    addEvent,
    deleteEvent
  };

  return (
    <DatabaseContext.Provider value={value}>
      {children}
    </DatabaseContext.Provider>
  );
};

export const useDatabase = (): DatabaseContextType => {
  const context = useContext(DatabaseContext);
  if (context === undefined) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
};
