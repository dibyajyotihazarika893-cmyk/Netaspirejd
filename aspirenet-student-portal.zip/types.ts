
export enum UserRole {
  Student = 'student',
  Admin = 'admin',
  Guest = 'guest',
}

export interface User {
  id: string;
  name: string;
  role: UserRole.Student | UserRole.Admin;
}

export enum MaterialType {
  PDF = 'pdf',
  Video = 'video',
}

export enum Category {
  SSC = 'SSC',
  UPSC = 'UPSC',
  APSC = 'APSC',
  HS = 'HS',
}

export interface BaseMaterial {
  id: string;
  title: string;
  description: string;
  category: Category;
}

export interface PdfMaterial extends BaseMaterial {
  type: MaterialType.PDF;
  price: number; // 0 for free
  fileUrl: string; // Will be a data URL for uploaded files
}

export interface VideoMaterial extends BaseMaterial {
  type: MaterialType.Video;
  youtubeId: string;
}

export type StudyMaterial = PdfMaterial | VideoMaterial;


// New Types for dynamic content
export interface ContactDetails {
  email: string;
  phone: string;
  address: string;
}

export interface Notification {
  id: string;
  message: string;
  date: string;
}

export interface EventItem {
  id: string;
  title: string;
  imageUrl: string;
}
